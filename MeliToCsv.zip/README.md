# CatcherMeliNFe
Extensão do google chrome que auxilia os vendedores do mercado livre a pegar dados fiscais para emitir nota em emissor externo ao da plataforma.
